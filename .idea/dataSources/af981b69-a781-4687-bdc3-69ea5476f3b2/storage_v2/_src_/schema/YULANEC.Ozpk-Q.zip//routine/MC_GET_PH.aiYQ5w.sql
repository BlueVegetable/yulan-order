create function mc_get_ph(str in varchar2) return varchar2 is
  Result varchar2(25);
  v_str1   number(8);
  v_str2   number(8);
  v_temp  varchar2(25);
  --v_strf  varchar2(1);
begin
  --substr(batch_no,1,instr(batch_no,'-',1)-1)
  v_str2:=instr(str,'-',1);
  v_str1:=instr(str,'_',1);
  if v_str1 <>0 then
          v_temp:= substr(str,1,v_str1-1);

  else
     if v_str2 <>0 then
            v_temp:= substr(str,1,v_str2-1);
    else
       if v_str1=0 then
        v_temp:= substr(str,1,length(str));
       else
        if v_str2=0 then
          v_temp:= substr(str,1,length(str));
          end if;
     end if;
     end if;
   end if;
  Result :=v_temp;
  return(Result);
end mc_get_ph;
/

