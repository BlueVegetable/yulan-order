create trigger ADDRESS_AUTOINC_TG
  before insert
  on POST_ADDRESS
  for each row
begin

select address_autoinc_seq.nextval into :new.ADDRESS_ID from dual;

end address_autoinc_tg;
/

