create PROCEDURE P_CUSTOMER_MONEY(v_customer_code varchar2) as

 -- v_customer_code  varchar2(10);


BEGIN


          SELECT "CUSTOMER"."CUSTOMER_CODE",
                 "CUSTOMER"."CUSTOMER_NAME",
                 nvl(recieve_money_lately.money,0) -nvl(month_close_balance_last.money,0) - nvl(consignment_money_lately_wx.money,0) - nvl(contractwx_money_lately.money,0)  as cust_balance_zt_wx
             FROM "CUSTOMER",
          (
          SELECT  a.customer_code,a.MONTH_END_RECEIVE_ZT as money
          FROM    SALE_GENERAL_LEDGER@ERP2EC a,customer b
          WHERE   a.customer_code = b.customer_code
          and b.customer_code = v_customer_code    --﾿ￍﾻﾧﾱ￤￁﾿
          AND     a.year_month = (select max(c.year_month)
                        from sale_general_ledger@ERP2EC c
                        where c.customer_code = b.customer_code)
          )month_close_balance_last,
          (
          select customer_code,
               sum((nvl(money_sum,0) + nvl(freight,0) + nvl(freight2,0)) * nvl(exch_rate,1))as money
          from pack_bill@ERP2EC a
          where status_id in ('1','2') and
                account_month <> 'NO' and

                customer_code = v_customer_code and  --﾿ￍﾻﾧﾱ￤￁﾿

              sale_type <> 'FL' and
              exists ( select 1 from pack_detail@ERP2EC b where a.sale_no = b.sale_no )
          group by customer_code
          )consignment_money_lately,
          (
          select customer_code,
               sum((decode(status_id,'1',decode(bill_id,'1',0,nvl(money_sum,0)),nvl(money_sum,0)) + nvl(freight,0) + nvl(freight2,0)) * nvl(exch_rate,1))as money
          from pack_bill@ERP2EC a
          where status_id in ('1','2') and
                account_month <> 'NO' and

                customer_code = v_customer_code and  --﾿ￍﾻﾧﾱ￤￁﾿

              sale_type <> 'FL' and
              exists ( select 1 from pack_detail@ERP2EC b where a.sale_no = b.sale_no )
          group by customer_code
          )consignment_money_lately_wx,

          (
          select  customer_code,sum(nvl(gather_money_fax,0) * nvl(exch_rate,1)) as money
          from money_gather@ERP2EC
          where status_id in ('1', '2') and
                trans_id_fax = 'N' and
                customer_code = v_customer_code and  --﾿ￍﾻﾧﾱ￤￁﾿
                account_month_fax <> 'NO'
          group by customer_code
          )recieve_money_lately,
          (
          select customer_code,sum( nvl(b.money,0) * nvl(a.exch_rate,1) ) as money
          from contract@ERP2EC a,contract_detail@ERP2EC b
          where a.contract_no = b.contract_no and
          a.customer_code = v_customer_code and  --﾿ￍﾻﾧﾱ￤￁﾿
          a.status_id in ('2','3','8','9','10') and
                b.status_id in ('2','3','8','9','10')
          group by customer_code
          )contractwx_money_lately
          WHERE  customer.customer_code =  month_close_balance_last.customer_code(+)
             AND customer.customer_code =  consignment_money_lately.customer_code(+)
             AND customer.customer_code =  consignment_money_lately_wx.customer_code(+)
             AND customer.customer_code =  recieve_money_lately.customer_code(+)
             AND customer.customer_code =  contractwx_money_lately.customer_code(+)
          and customer.customer_code = v_customer_code ;--﾿ￍﾻﾧﾱ￤￁﾿



end;
/

